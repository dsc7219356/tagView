//
//  ScrollTagView.m
//  BH_Doctor
//
//  Created by Chengshao on 16/8/23.
//  Copyright © 2016年 南京毗邻智慧医疗科技有限公司. All rights reserved.
//

#import "ScrollTagView.h"
#define SCREENWIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREENHEIGHT ([UIScreen mainScreen].bounds.size.height)
#define COMMONBLUE [UIColor colorWithRed:27/255.0 green:153/255.0 blue:225/255.0 alpha:1.0]//通用蓝色
@implementation ScrollTagView{
    
    NSMutableArray *mTagArr;
    NSMutableArray *mSelectedTagArr;
    
    NSInteger mSpaceMargin; // 标签之间的间距
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder]) {
        [self setUpUI];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setUpUI];
    }
    return self;
}

- (id)init {
    
    if (self = [super init]) {
        [self setUpUI];
        
    }
    return self;
}


- (void)setUpUI {
    
    self.contentSize = CGSizeMake(0, SCREENHEIGHT);
    
    _labWidht = 90.0f;
    _labHeight = 20.0f;
    
    _labTextFont = 15.0f;
    _cornerValue = 10.0f;
    _bgColor = [UIColor whiteColor];
    _textColor = [UIColor blackColor];
    _totalCols = 3;
    _isDisplayDel = NO;
    _isShowSelectedBg = NO;
    _selectedBgColor = COMMONBLUE;
    
    _spaceTBMargin = 10.0f;
    _spaceLeft = 15.0f;
    _spaceRight = 15.0f;
    
    _showWidht = SCREENWIDTH;
    
}


- (void)setTagArray:(NSArray *)tagArray{
    
    mTagArr = [NSMutableArray arrayWithArray:tagArray];
    
    [self createUI];
}

- (void)setSelectedTagArray:(NSArray *)selectedTagArr{
    
    mSelectedTagArr = [NSMutableArray arrayWithArray:selectedTagArr];
}


// 根据数组设置标签
- (void)createUI{
    
    // 移除所有控件
    for (id obj in self.subviews) {
        [obj removeFromSuperview];
    }
    
    mSpaceMargin = (_showWidht - (_totalCols * _labWidht + _spaceLeft + _spaceRight)) / (_totalCols-1);
    
    NSInteger totalCols = self.totalCols; // 一行显示3个
    for (int i = 0; i < mTagArr.count; i ++) {
        
        NSInteger row = i / totalCols;
        NSInteger col = i % totalCols;
        
        
        UILabel *tagLab = [[UILabel alloc] init];
        tagLab.frame = CGRectMake(_spaceLeft + (col * (_labWidht + mSpaceMargin)), _spaceTBMargin + (row * (_labHeight + _spaceTBMargin)),_labWidht , _labHeight);
        tagLab.userInteractionEnabled = YES;
        tagLab.tag = i;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(btnClick:)];
        [tagLab addGestureRecognizer:tap];
        
        tagLab.text = mTagArr[i];
        tagLab.textAlignment = NSTextAlignmentCenter;
        tagLab.font = [UIFont systemFontOfSize:_labTextFont];
        tagLab.layer.cornerRadius = _cornerValue;
        tagLab.layer.masksToBounds = YES;
        tagLab.layer.borderWidth = 1.0f;
        tagLab.layer.borderColor = [UIColor grayColor].CGColor;
        // 标记已经选中的标签
        if (_isShowSelectedBg && [mSelectedTagArr containsObject:mTagArr[i]]) {
            
            tagLab.backgroundColor = COMMONBLUE;
            tagLab.textColor = [UIColor whiteColor];
            
        } else{
            
            tagLab.textColor = _textColor;
            tagLab.backgroundColor = _bgColor;
        }
        
        [self addSubview:tagLab];
        
        // 按钮标签
        
        //        UIButton *tagBtn = [[UIButton alloc] init];
        //        [tagBtn setTitle:mTagArr[i] forState:UIControlStateNormal];
        //        [tagBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        //        [tagBtn setTitleColor:_textColor forState:UIControlStateNormal];
        //        [tagBtn setTitleColor:_textColor forState:UIControlStateNormal];
        //        tagBtn.backgroundColor = _bgColor;
        //        tagBtn.titleLabel.font = [UIFont systemFontOfSize:_labTextFont];
        //        tagBtn.layer.borderWidth = 0.5f;
        //        tagBtn.layer.borderColor = [[UIColor lightGrayColor] CGColor];
        //        tagBtn.layer.cornerRadius = _cornerValue;
        //        tagBtn.layer.masksToBounds = YES;
        //
        //        [self addSubview:tagBtn];
        //
        
        // 删除按钮
        if (self.isDisplayDel) {
            
            UIButton *deleteBtn = [[UIButton alloc] init];
            //            deleteBtn.frame = CGRectMake(mBtn.frame.size.width - 8, -7, 15, 15);
            
            CGFloat X = CGRectGetMaxX(tagLab.frame) - 8;
            CGFloat Y = tagLab.frame.origin.y - 7;
            
            deleteBtn.frame = CGRectMake(X, Y, 15, 15);
            [deleteBtn setBackgroundImage:[UIImage imageNamed:@"icon_del"] forState:UIControlStateNormal];
            [deleteBtn addTarget:self action:@selector(deleteBtnClick:) forControlEvents:UIControlEventTouchUpInside];
            
            deleteBtn.tag = i;
            
            [self addSubview:deleteBtn];
            
            tagLab.layer.masksToBounds = NO;
        }
        
        self.tagViewHeight = CGRectGetMaxY(tagLab.frame) + 2 * _spaceTBMargin;
        
        self.contentSize = CGSizeMake(0, self.tagViewHeight);
    }
    
}

- (void)btnClick:(UITapGestureRecognizer *)tap {
    
    UILabel *lab = (UILabel *)tap.view;
    
    if (_isShowSelectedBg) { // 显示选中颜色
        
        if ([lab.textColor isEqual:[UIColor whiteColor]]) { // 选中状态
            lab.backgroundColor = [UIColor whiteColor];
            lab.textColor = _textColor;
            
            if (self.scrollTagViewDelegate && [self.scrollTagViewDelegate respondsToSelector:@selector(scrollTagView:cancelSelectTagAtIndex:)]) {
                
                [self.scrollTagViewDelegate scrollTagView:self cancelSelectTagAtIndex:lab.tag];
            }
            
        } else{
            lab.backgroundColor = COMMONBLUE;
            lab.textColor = [UIColor whiteColor];
            
            if (self.scrollTagViewDelegate && [self.scrollTagViewDelegate respondsToSelector:@selector(scrollTagView:didSelectTagAtIndex:)]) {
                
                [self.scrollTagViewDelegate scrollTagView:self didSelectTagAtIndex:lab.tag];
            }
            
        }
        
        
    } else{
        
        if (self.scrollTagViewDelegate && [self.scrollTagViewDelegate respondsToSelector:@selector(scrollTagView:didSelectTagAtIndex:)]) {
            
            [self.scrollTagViewDelegate scrollTagView:self didSelectTagAtIndex:lab.tag];
        }
        
    }
    
}

- (void)deleteBtnClick:(UIButton *)deleteBtn{
    
    if (self.scrollTagViewDelegate && [self.scrollTagViewDelegate respondsToSelector:@selector(scrollTagView:deleteTagAtIndex:)]) {
        
        [self.scrollTagViewDelegate scrollTagView:self deleteTagAtIndex:deleteBtn.tag];
    }
    
}



@end
