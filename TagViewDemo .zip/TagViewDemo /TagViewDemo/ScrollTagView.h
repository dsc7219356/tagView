//
//  ScrollTagView.h
//  BH_Doctor
//
//  Created by Chengshao on 16/8/23.
//  Copyright © 2016年 南京毗邻智慧医疗科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ScrollTagView;

@protocol ScrollTagViewDelegate <NSObject>

@optional
// 选择
- (void)scrollTagView:(ScrollTagView *)tagView didSelectTagAtIndex:(NSInteger)index;
// 取消选中
- (void)scrollTagView:(ScrollTagView *)tagView cancelSelectTagAtIndex:(NSInteger)index;
// 删除
- (void)scrollTagView:(ScrollTagView *)tagView deleteTagAtIndex:(NSInteger)index;

@end

@interface ScrollTagView : UIScrollView

- (void)setTagArray:(NSArray *)tagArray; // 需要显示的标签数组
- (void)setSelectedTagArray:(NSArray *)selectedTagArr; // 选中的标签数组

//@property (nonatomic,assign) CGFloat spaceMargin;//标签之间的间距
@property (nonatomic,assign) CGFloat spaceTBMargin;//标签上下之间的距离,默认与spaceMargin相等
@property (nonatomic,assign) CGFloat spaceLeft;//标签距离左边距
@property (nonatomic,assign) CGFloat spaceRight;//标签距离右最小边距,默认与左边距相等
@property (nonatomic,assign) CGFloat labHeight;//标签高度
@property (nonatomic,assign) CGFloat labWidht;//标签宽度
@property (nonatomic,assign) CGFloat labTextFont;//标签字体大小
@property (nonatomic,strong) UIColor *bgColor;//标签背景颜色
@property (nonatomic,strong) UIColor *textColor;//标签字体颜色
@property (nonatomic,assign) CGFloat cornerValue; // 圆角
@property (nonatomic,assign) CGFloat tagViewHeight; // 标签View的整体高度
@property (nonatomic,assign) NSInteger totalCols; // 一行显示几列
@property (nonatomic,assign) CGFloat showWidht; // 标签显示区域宽度
@property (nonatomic,assign) BOOL isDisplayDel; // 是否显示删除按钮  default is NO
@property (nonatomic,strong) UIColor *selectedBgColor; // 选中状态下的背景颜色
@property (nonatomic,assign) BOOL isShowSelectedBg; // 是否显示选中状态的背景颜色  default is NO


@property (nonatomic, weak) id<ScrollTagViewDelegate> scrollTagViewDelegate;


@end
