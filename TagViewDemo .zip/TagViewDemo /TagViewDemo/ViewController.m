//
//  ViewController.m
//  TagViewDemo
//
//  Created by Chengshao on 2017/3/2.
//  Copyright © 2017年 BH. All rights reserved.
//

#import "ViewController.h"
#import "ScrollTagView.h"
#define SCREENWIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREENHEIGHT ([UIScreen mainScreen].bounds.size.height)

@interface ViewController ()<ScrollTagViewDelegate>


{
    ScrollTagView *mTagView;
    NSMutableArray *mDataSource;
    NSMutableArray *mSelectedArr; // 选中的标签
    
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    mSelectedArr = [NSMutableArray array];
    mDataSource = [NSMutableArray arrayWithObjects:@"社科",@"认知智慧节目",@"文学",@"文化艺术",@"科技",@"科学",@"两性",@"家庭",@"亲子",@"健康",@"生活方式",@"沟通",@"创业",@"互联网",@"金融",@"财富",@"职场",@"管理",@"商业",@"经济学",@"思维",@"心理学",@"历史",@"趋势",@"自我管理",@"方法技能",@"学科通识", nil];
    
    mTagView = [[ScrollTagView alloc]initWithFrame:CGRectMake(0, 64, SCREENWIDTH, SCREENHEIGHT)];
    mTagView.showWidht = SCREENWIDTH;
    
    mTagView.totalCols = 4;
    mTagView.labTextFont = 12;
    
    mTagView.spaceLeft = 10;
    mTagView.spaceRight = 10;
    mTagView.cornerValue = 5;
    mTagView.labWidht = (SCREENWIDTH-50)/4;
    
    mTagView.textColor = [UIColor grayColor];
    mTagView.labHeight = 30;
    mTagView.spaceTBMargin = 20;
    mTagView.isShowSelectedBg = YES;
    mTagView.scrollTagViewDelegate = self;
    [mTagView setTagArray:mDataSource];
    [self.view addSubview:mTagView];
    
}

- (void)scrollTagView:(ScrollTagView *)tagView didSelectTagAtIndex:(NSInteger)index
{
    
}
- (void)scrollTagView:(ScrollTagView *)tagView cancelSelectTagAtIndex:(NSInteger)index
{
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
